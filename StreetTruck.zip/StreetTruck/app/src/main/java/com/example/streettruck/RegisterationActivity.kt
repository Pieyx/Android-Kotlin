package com.example.streettruck

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class RegisterationActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registeration)
    }
}